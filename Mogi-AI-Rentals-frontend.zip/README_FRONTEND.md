# Mogi AI Rentals — Frontend

This frontend uses Vite + React + Tailwind. Set environment variable REACT_APP_API_BASE to your backend API base (e.g. https://mogi-backend.onrender.com/api)

Commands:
- `npm install`
- `npm run dev` (development)
- `npm run build` (production build)
