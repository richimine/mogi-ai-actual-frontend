import React from 'react'
export default function Table({children}){ return <table className="w-full table-auto">{children}</table> }