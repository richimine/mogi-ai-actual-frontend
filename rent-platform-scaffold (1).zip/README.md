Rent Collection Platform - Scaffold
See README in project.
