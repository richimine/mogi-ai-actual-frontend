'use client';
import { useState } from 'react';

export default function ChatWidget() {
  const [msg, setMsg] = useState('');
  const [log, setLog] = useState([]);

  async function send() {
    if (!msg) return;
    setLog(l=>[...l, {from:'you', text:msg}]);
    const res = await fetch('/api/ai/chat', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({message: msg})});
    const j = await res.json();
    setLog(l=>[...l, {from:'bot', text: j.reply}]);
    setMsg('');
  }

  return (
    <div style={{position:'fixed', right:20, bottom:20, width:320, background:'#fff', border:'1px solid #ddd', borderRadius:8, padding:10}}>
      <div style={{height:200, overflowY:'auto', marginBottom:8}}>
        {log.map((m,i)=>(<div key={i} style={{padding:4}}><strong>{m.from}:</strong> {m.text}</div>))}
      </div>
      <input value={msg} onChange={e=>setMsg(e.target.value)} style={{width:'calc(100% - 60px)'}}/>
      <button onClick={send} style={{width:50}}>Send</button>
    </div>
  )
}
