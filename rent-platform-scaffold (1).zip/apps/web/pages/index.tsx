import Image from 'next/image';
import ChatWidget from '../components/ChatWidget';

export default function Home() {
  return (
    <main style={{fontFamily:'system-ui, sans-serif', padding: '2rem'}}>
      <h1>Rent Collection Platform (Demo)</h1>
      <p>Multi-tenant rent collection & AI support — demo scaffold.</p>
      <Image src="/assets/hero.jpeg" alt="hero" width={800} height={400} />
      <p><a href="/dashboard">Go to dashboard (demo)</a></p>
      <ChatWidget />
    </main>
  )
}
