export default function Dashboard() {
  return (
    <main style={{fontFamily:'system-ui, sans-serif', padding: '2rem'}}>
      <h1>Landlord Dashboard — Demo</h1>
      <p>This is a static demo page. Integrate with API for full functionality.</p>
    </main>
  )
}
