import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.get('/health', (req, res) => res.json({status: 'ok'}));

app.post('/api/payments/mpesa/stk', (req, res) => {
  const { phone, amount, invoiceId } = req.body;
  console.log('STK push request', phone, amount, invoiceId);
  res.json({ CheckoutRequestID: 'TEST_CHECKOUT_' + Date.now() });
});

app.post('/api/payments/webhook/mpesa', (req, res) => {
  console.log('MPesa webhook received', JSON.stringify(req.body).slice(0,200));
  res.status(200).send('OK');
});

app.post('/api/ai/chat', async (req, res) => {
  const { message } = req.body;
  res.json({ reply: `Hi — RentBot heard: '${message || ''}' (demo reply)` });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log('API server running on port', PORT));
